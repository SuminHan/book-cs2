L08_Robot - Robot class (Hubo) example for CS2 Lecture 7/8

How to run
  1. Unzip and open a terminal in this folder.
  2. pip install pillow        (tkinter is also required; it comes with
                                most Python installs, e.g. Anaconda)
  3. python L08_Robot.py
  Close the robot window to end the program.

Files
  L08_Robot.py         example: hubo picks up beepers, jumps over hurdles,
                       comes back to (1,1) and drops them
  worlds/              world file used by the example
  cs1robots.py         robot library (KAIST CS101, Otfried Cheong;
                       Python 3 port by Jungkook Park, 2015).
                       turn_right() added (= turn_left three times).
  cs1robots_images.py  robot images used by cs1robots
  cs1graphics.py       graphics library (Letscher, Goldwasser, Porter)
  easygui.py           file dialog helper used by cs1robots

License
  cs1robots.py and cs1graphics.py are distributed under the GNU General
  Public License v3. Original sources:
    https://github.com/otfried/cs101
    http://www.cs1graphics.org/
