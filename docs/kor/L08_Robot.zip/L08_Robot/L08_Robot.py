# L08 slides: Robot class (for Hubo)
# cs1robots.py, cs1graphics.py, cs1robots_images.py, easygui.py and the
# worlds folder must be in the same folder as this file.
#
# hubo collects every beeper on street 1, jumping over the hurdles (walls),
# then comes back to (1,1) and drops all the beepers there.
from cs1robots import *

load_world("./worlds/hurdles_beepers.wld")

hubo = Robot(beepers = 0)       # __init__(hubo, 0) invoked
hubo.set_trace("blue")
hubo.set_pause(0.2)

amy = Robot(color = "yellow", avenue = 1, street = 4)   # another object


def turn_around():
    hubo.turn_left()
    hubo.turn_left()

def jump_over_hurdle():
    # go up, over the wall, and back down
    if hubo.left_is_clear():    # facing east: "up" is on the left
        hubo.turn_left()
        hubo.move()
        hubo.turn_right()
        hubo.move()
        hubo.turn_right()
        hubo.move()
        hubo.turn_left()
    else:                       # facing west: "up" is on the right
        hubo.turn_right()
        hubo.move()
        hubo.turn_left()
        hubo.move()
        hubo.turn_left()
        hubo.move()
        hubo.turn_right()

def pick_all_beepers():
    while hubo.on_beeper():
        hubo.pick_beeper()      # modifier: changes hubo._beeper_bag

def go_until(avenue):
    # move along street 1 until hubo reaches the given avenue
    while hubo.get_pos()[0] != avenue:
        pick_all_beepers()
        if hubo.front_is_clear():
            hubo.move()
        else:                   # wall in front -> jump over it
            jump_over_hurdle()
    pick_all_beepers()


def robot_main():
    go_until(10)                # east to the end of street 1
    print(hubo._beeper_bag)     # 7

    turn_around()
    go_until(1)                 # back home

    while hubo.carries_beepers():   # pure function: only reads the state
        hubo.drop_beeper()

    # each object has its own state variables
    print(hubo.get_pos(), hubo._beeper_bag)   # (1, 1) 0
    print(amy.get_pos(), amy._beeper_bag)     # (1, 4) 0


if __name__ == '__main__': robot_main()
