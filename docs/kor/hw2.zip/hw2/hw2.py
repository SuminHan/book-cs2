class Teacher(object):
    def __init__(self, quota):
        self.prefList = None  # preference list (of Student objects)
        self.quota = quota    # maximum possible number of students
        self.apprentice = []  # list of students to supervise
        self.numProposal = 0  

    def quotaAvailable(self):
        return len(self.apprentice) < self.quota
        
    def nextStudent(self): 
        assert self.numProposal < len(self.prefList)
        s = self.prefList[self.numProposal]
        self.numProposal += 1
        return s

####################################################################
class Student(object):
    def __init__(self, id):
        self.prefList = None  # preference list (of Teacher objects)
        self.advisor = None  # teacher who will supervise self's research
        self.id = id  # for printing/debugging
        
    def isFree(self):
        return self.advisor == None

    def prefer(self, p):  # whether or not self prefer p to current advisor
        assert type(p) == Teacher
        assert not self.isFree()
        i = self.prefList.index(self.advisor)
        j = self.prefList.index(p)
        return j < i
        
    def engage(self, p):
        assert type(p) == Teacher
        assert self.isFree()
        assert self not in p.apprentice and p.quotaAvailable()
        self.advisor = p
        p.apprentice.append(self)
        
    def breakUp(self):
        assert not self.isFree()
        assert self in self.advisor.apprentice
        self.advisor.apprentice.remove(self)
        self.advisor = None

####################################################################
def findMatch(teachers, students):
    n = len(teachers)
    m = len(students)

    # ADD ADDITIONAL CODE HERE!

    
    
####################################################################
from hw2_check import *

def test():
    T = 50
    correct = True
    for h in range(T):
        teachers, students = o0o00o0(h)
        findMatch(teachers, students)

        perfect, stable = O000OO0(teachers, students)

        if not (perfect and stable):
            print("Incorrect output for %d-th input" % (h+1), end=" ")
            if not perfect:
                print(": not even perfect")
            else:
                assert not stable
                print(": perfect but not stable")
            correct = False
        else:
            print("Correct output for %d-th input" % (h+1))
    if correct:
        print("Correct for all %d inputs" % (T))

test()