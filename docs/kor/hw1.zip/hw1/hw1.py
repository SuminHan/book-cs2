# In case of need, define your own sub-functions



def solve(M):
    # IMPLEMENT HERE!!
    return -1  # remove this after completion


    
# You may use the following simple test case
M1 = [ [0, 0, 0, 0, 0, 0],
       [0, 0, 1, 0, 0, 0],
       [0, 2, 3, 4, 5, 0],
       [0, 0, 6, 0, 0, 0],
       [0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0] ]
M2 = [ [0, 0, 0, 0, 0, 0],
       [0, 5, 0, 4, 0, 0],
       [0, 1, 2, 3, 0, 0],
       [0, 0, 0, 6, 0, 0],
       [0, 0, 0, 0, 0, 0],
       [0, 0, 0, 0, 0, 0] ]
M3 = [ [0, 0, 0, 0, 0, 0],
       [0, 0, 1, 0, 0, 2],
       [0, 0, 3, 0, 0, 0],
       [0, 0, 4, 0, 0, 5],
       [0, 0, 0, 0, 0, 6],
       [0, 0, 0, 0, 0, 0] ]
print(solve(M1))  # 6
print(solve(M2))  # 0
print(solve(M3))  # 0

####################################################################
def test():
    s = open("./hw1.in", "r").read().split()
    L = [int(x)  for x in s]
    N = L.pop(0)  # num. of test inputs
    correct = True
    for h in range(N):
        M = [ [None]*6  for i in range(6) ]
        for i in range(6):
            for j in range(6):
                M[i][j] = L.pop(0)
        sol = L.pop(0)
        r = solve(M)
        if r != sol:
            print("Incorrect output for %d-th input" % (h+1))
            correct = False
    if correct:
        print("Correct for all inputs")
            
test()